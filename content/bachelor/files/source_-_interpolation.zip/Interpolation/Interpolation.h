void loadImg( const char* path, unsigned char *img, int width, int height)
{	
	if ( path == 0 ) exit(EXIT_FAILURE);
	if( FILE * file = fopen(path,"r") )
	{
		unsigned char *temp = (unsigned char*) malloc(width * height * sizeof(unsigned char) );
		FILE *input = fopen(path,"rb");
		fread(temp,1,width * height * sizeof(unsigned char),input);
		fclose(input);
		
		for(int i = 0; i < width*height; i++)
		{
			img[i*4] = img[i*4+1] = img[i*4+2] = temp[i];
			img[i*4+3] = 0;
		}
	}
	else exit(EXIT_FAILURE);
}
void saveImg( const char* path, unsigned char *img, int width, int height)
{	
		unsigned char *temp = (unsigned char*) malloc(width * height * sizeof(unsigned char) );
		for(int i = 0; i < width*height; i++)
			temp[i] = img[i*4];
		FILE *output = fopen(path,"w");
		fwrite(temp,1,width * height * sizeof(unsigned char),output);
		fclose(output);
}

void assignMatrix(float in[4][2], float out[4][2])
{
	for(int i = 0; i < 4; i++)
		for(int j = 0; j < 2; j++)
			out[i][j] = in[i][j];
}
void getMatrix(float ref[4][2], float src[4][2], float coefficients[3][3])
{
    float a[3][3];
    float b[3][3];
    float bIn[3][3];
    float c[3][3];
    float indetB;
    float indetC;

    // A -> a
	a[2][0] = ((ref[3][0]-ref[2][0]+ref[1][0]-ref[0][0])*(ref[0][1]-ref[1][1])-(ref[3][1]-ref[2][1]+ref[1][1]-ref[0][1])*(ref[0][0]-ref[1][0])) / ((ref[2][0]-ref[1][0])*(ref[0][1]-ref[1][1])-(ref[0][0]-ref[1][0])*(ref[2][1]-ref[1][1]));
	a[2][1] = ((ref[3][1]-ref[2][1]+ref[1][1]-ref[0][1])*(ref[2][0]-ref[1][0])-(ref[3][0]-ref[2][0]+ref[1][0]-ref[0][0])*(ref[2][1]-ref[1][1])) / ((ref[2][0]-ref[1][0])*(ref[0][1]-ref[1][1])-(ref[0][0]-ref[1][0])*(ref[2][1]-ref[1][1]));
	a[2][2] = 1.0f;
	a[1][0] = ref[2][1]-ref[3][1]+a[2][0]*ref[2][1];
	a[1][1] = ref[0][1]-ref[3][1]+a[2][1]*ref[0][1];
	a[1][2] = ref[3][1];
	a[0][0] = ref[2][0]-ref[3][0]+a[2][0]*ref[2][0];
	a[0][1] = ref[0][0]-ref[3][0]+a[2][1]*ref[0][0];
	a[0][2] = ref[3][0];

    // B -> b
	b[2][0] = ((src[3][0]-src[2][0]+src[1][0]-src[0][0])*(src[0][1]-src[1][1])-(src[3][1]-src[2][1]+src[1][1]-src[0][1])*(src[0][0]-src[1][0])) / ((src[2][0]-src[1][0])*(src[0][1]-src[1][1])-(src[0][0]-src[1][0])*(src[2][1]-src[1][1]));
	b[2][1] = ((src[3][1]-src[2][1]+src[1][1]-src[0][1])*(src[2][0]-src[1][0])-(src[3][0]-src[2][0]+src[1][0]-src[0][0])*(src[2][1]-src[1][1])) / ((src[2][0]-src[1][0])*(src[0][1]-src[1][1])-(src[0][0]-src[1][0])*(src[2][1]-src[1][1]));
	b[2][2] = 1.0f;
	b[1][0] = src[2][1]-src[3][1]+b[2][0]*src[2][1];
	b[1][1] = src[0][1]-src[3][1]+b[2][1]*src[0][1];
	b[1][2] = src[3][1];
	b[0][0] = src[2][0]-src[3][0]+b[2][0]*src[2][0];
	b[0][1] = src[0][0]-src[3][0]+b[2][1]*src[0][0];
	b[0][2] = src[3][0];

	// b^-1
	indetB = 1/(a[0][0]*(a[2][2]*a[1][1]-a[2][1]*a[1][2])-a[1][0]*(a[2][2]*a[0][1]-a[2][1]*a[0][2])+a[2][0]*(a[1][2]*a[0][1]-a[1][1]*a[0][2]));	
	bIn[0][0] = indetB * ( b[2][2]*b[1][1]-b[2][1]*b[1][2] );
	bIn[0][1] = -1.0f * indetB * ( b[2][2]*b[0][1]-b[2][1]*b[0][2] );
	bIn[0][2] = indetB * ( b[1][2]*b[0][1]-b[1][1]*b[0][2] );
	bIn[1][0] = -1.0f * indetB * ( b[2][2]*b[1][0]-b[2][0]*b[1][2] );
	bIn[1][1] = indetB * ( b[2][2]*b[0][0]-b[2][0]*b[0][2] );
	bIn[1][2] = -1.0f * indetB * ( b[1][2]*b[0][0]-b[1][0]*b[0][2] );
	bIn[2][0] = indetB * ( b[2][1]*b[1][0]-b[2][0]*b[1][1] );
	bIn[2][1] = -1.0f * indetB * ( b[2][1]*b[0][0]-b[2][0]*b[0][1] );
	bIn[2][2] = indetB * ( b[1][1]*b[0][0]-b[1][0]*b[0][1] );

	// c = a * b^-1
	for (int i = 0; i < 3; i++)
	{ 
	  for (int j = 0; j < 3; j++)
	  {
		 c[i][j] = 0.0;
		for (int k = 0; k < 3; k++)
		{
		   c[i][j] += a[i][k] * bIn[k][j];
		}
	  }
	}

	// c^-1 -> coefficents for projective transformation
	indetC = 1/(a[0][0]*(a[2][2]*a[1][1]-a[2][1]*a[1][2])-a[1][0]*(a[2][2]*a[0][1]-a[2][1]*a[0][2])+a[2][0]*(a[1][2]*a[0][1]-a[1][1]*a[0][2]));	
	coefficients[0][0] = indetC * ( c[2][2]*c[1][1]-c[2][1]*c[1][2] );
	coefficients[0][1] = -1.0f * indetC * ( c[2][2]*c[0][1]-c[2][1]*c[0][2] );
	coefficients[0][2] = indetC * ( c[1][2]*c[0][1]-c[1][1]*c[0][2] );
	coefficients[1][0] = -1.0f * indetC * ( c[2][2]*c[1][0]-c[2][0]*c[1][2] );
	coefficients[1][1] = indetC * ( c[2][2]*c[0][0]-c[2][0]*c[0][2] );
	coefficients[1][2] = -1.0f * indetC * ( c[1][2]*c[0][0]-c[1][0]*c[0][2] );
	coefficients[2][0] = indetC * ( c[2][1]*c[1][0]-c[2][0]*c[1][1] );
	coefficients[2][1] = -1.0f * indetC * ( c[2][1]*c[0][0]-c[2][0]*c[0][1] );
	coefficients[2][2] = indetC * ( c[1][1]*c[0][0]-c[1][0]*c[0][1] );
}

void bilinear(unsigned char *out, unsigned char *in, float mat[3][3], int width, int height)
{
	int imSize = width * height;
	int u, v;
	float xn, yn, a, b, A, B, C, D, E, F;

	for(int y = 0; y < height; y++)
	for(int x = 0; x < width; x++)
	{ 
		xn = (mat[0][0]*x+mat[0][1]*y+mat[0][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2]);
		yn = (mat[1][0]*x+mat[1][1]*y+mat[1][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2]);
		u = (int) xn;
		v = (int) yn;
		if( u < width && v < height && u >= 0 && v >= 0)
		{
			a = xn - (float) u; 
			b = yn - (float) v; 
			A = in[(width*v+u)*4];
			B = in[(width*v+(u+1))*4];
			C = in[(width*(v+1)+u)*4];
			D = in[(width*(v+1)+(u+1))*4];
			E = A + a*(B-A);
			F = C + a*(D-C);
			out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = E + b*(F-E);
		}
		else out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = 0;
	}
}
void nearestNeighbor(unsigned char *out, unsigned char *in, float mat[3][3], int width, int height)
{
	int imSize = width * height;
	int u, v;
	float xn, yn;

	for(int y = 0; y < height; y++)
	for(int x = 0; x < width; x++)
	{ 
		xn = ((mat[0][0]*x+mat[0][1]*y+mat[0][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2])) - 0.5;
		yn = ((mat[1][0]*x+mat[1][1]*y+mat[1][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2])) - 0.5;
		u = (int) ceil(xn);
		v = (int) ceil(yn);
		if( u < width && v < height && u >= 0 && v >= 0)
		{
			out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = in[(width*v+u)*4];;
		}
		else out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = 0;
	}
}
void noInterpolation(unsigned char *out, unsigned char *in, float mat[3][3], int width, int height)
{
	int imSize = width * height;
	float u, v;

	for(int x = 0; x < width*height; x++)
		out[x*4] = out[x*4 + 1] = out[x*4 + 2] = 0;	
	
	for(int y = 0; y < height; y++)
	for(int x = 0; x < width; x++)
	{ 
		u = (mat[0][0]*x+mat[0][1]*y+mat[0][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2]);
		v = (mat[1][0]*x+mat[1][1]*y+mat[1][2]) / (mat[2][0]*x+mat[2][1]*y+mat[2][2]);

		if( u < width && v < height && u >= 0 && v >= 0 && v == (int)v && u == (int)u)
			out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = in[4*(width*(int)v+(int)u)];;
	}
}
void noTransform(unsigned char *out, unsigned char *in, float mat[3][3], int width, int height)
{
	for(int y = 0; y < height; y++)
	for(int x = 0; x < width; x++)
	{ 
		out[(width*y+x)*4] = out[(width*y+x)*4 + 1] = out[(width*y+x)*4 + 2] = in[(width*y+x)*4];
	}
}