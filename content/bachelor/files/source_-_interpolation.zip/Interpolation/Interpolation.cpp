#pragma comment(lib, "glut32.lib")
#include <windows.h>
//#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>
#include <math.h>
#include <Interpolation.h>

int w = 400;
int h = 400;
unsigned char *img = NULL;
unsigned char *tex = NULL;
GLuint texID;

int mode = 0;
int count = 0; // count mouse clicks
int circle = 0; // transformation matrix

float src_i[4][2] = {{-590, 1190}, {1190, 1190}, {1190, -590}, {-590, -590}}; // scale even a bit more up	
float src_h[4][2] = {{-500, 1100}, {1100, 1100}, {1100, -500}, {-500, -500}}; // scale even a bit more up	
float src_g[4][2] = {{-300, 900}, {900, 900}, {900, -300}, {-300, -300}}; // scale a bit more up	
float src_f[4][2] = {{-150, 750}, {750, 750}, {750, -150}, {-150, -150}}; // scale a bit up	
float src_e[4][2] = {{150, 450}, {450, 450}, {450, 150}, {150, 150}}; // scale a bit down
float src_d[4][2] = {{100, 600}, {600, 500}, {500, 0}, {0, 100}}; // scale and rotate
float src_c[4][2] = {{0, 300}, {300, 600}, {600, 300}, {300, 0}}; // scale a bit and rotate by 90*
float src_b[4][2] = {{200, 580}, {500, 350}, {590, 150}, {0, 0}}; // deform
float src_a[4][2] = {{0, 600}, {600, 600}, {600, 0}, {0, 0}}; // original
float src[4][2] = {{0, 600}, {600, 600}, {600, 0}, {0, 0}};;

float tar[4][2] = {{0, 600}, {600, 600}, {600, 0}, {0, 0}};
float mat[3][3];

void renderScene(void) 
{
	glClear(GL_COLOR_BUFFER_BIT);	
	glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
	
	switch(mode)
	{
		case 0:
			noTransform(tex, img, mat, w, h);
			break;
		case 1:
			noInterpolation(tex, img, mat, w, h);
			break;
		case 2:
			nearestNeighbor(tex, img, mat, w, h);
			break;
		case 3:
			bilinear(tex, img, mat, w, h);
			break;
	}
		
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, tex);	
	glColor3f(1.0f,1.0f,1.0f);
	glBegin( GL_QUADS);
        glTexCoord2f(0.0f, 0.0f);          
        glVertex2f(-1.0f, -1.0f);
        glTexCoord2f(1.0f, 0.0f);          
        glVertex2f(+1.0f,-1.0f);
        glTexCoord2f(1.0f, 1.0f);          
        glVertex2f(+1.0f, +1.0f);
        glTexCoord2f(0.0f, 1.0f);          
        glVertex2f(-1.0f, +1.0f);   
    glEnd();
	glutSwapBuffers();
}

void keys(unsigned char key, int x, int y) 
{
	switch(key)
	{
		case 27: // 27 entspricht ESC
			exit(0);
			printf("Good bye!");
			break;
		case 49:
			mode = 0;
			printf("Display mode changed: no transformation\n");	
			break;
		case 50:
			mode = 1;
			printf("Display mode changed: transformed, no interpolation\n");	
			break;
		case 51:
			mode = 2;
			printf("Display mode changed: transformed, nearest neighbor interpolation\n");	
			break;
		case 52:
			mode = 3;
			printf("Display mode changed: transformed, bilinear interpolation\n");	
			break; 
		case 43:
			for(int i = 0; i < 4; i++)
			for(int j = 0; j < 2; j++)
				src[i][j] *= 1.2; 
			getMatrix(src, tar, mat);
			break;
		case 45:
			for(int i = 0; i < 4; i++)
			for(int j = 0; j < 2; j++)
				src[i][j] *= 1.0/1.2; 
			getMatrix(src, tar, mat);
			break;
		case 119:
			for(int i = 0; i < 4; i++)
				src[i][1] -= 5; 
			getMatrix(src, tar, mat);
			break;		
		case 115:
			for(int i = 0; i < 4; i++)
				src[i][1] += 5; 
			getMatrix(src, tar, mat);
			break;	
		case 97:
			for(int i = 0; i < 4; i++)
				src[i][0] -= 5; 
			getMatrix(src, tar, mat);
			break;		
		case 100:
			for(int i = 0; i < 4; i++)
				src[i][0] += 5; 
			getMatrix(src, tar, mat);
			break;
		case 'p':
			saveImg( "output.raw", tex, w, h);
			printf("Image saved!\n");
			break;
		case 13:
			circle = (circle == 8)?0:circle+1;
			switch(circle)
			{
				case 0:
					assignMatrix(src_a,src);
					break;
				case 1:
					assignMatrix(src_b,src);
					break;
				case 2:
					assignMatrix(src_c,src);
					break;
				case 3:
					assignMatrix(src_d,src);
					break;
				case 4:
					assignMatrix(src_e,src);
					break;
				case 5:
					assignMatrix(src_f,src);
					break;
				case 6:
					assignMatrix(src_g,src);
					break;
				case 7:
					assignMatrix(src_h,src);
					break;
				case 8:
					assignMatrix(src_i,src);
					break;
			}
			getMatrix(src, tar, mat);
			break;
	}
}
void mouse( int button, int state, int x, int y)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
	{
		float xi = ((float)x/(float)glutGet(GLUT_WINDOW_WIDTH))*(float)w;
		float yi = ((float)y/(float)glutGet(GLUT_WINDOW_HEIGHT))*(float)h;
		switch(count)
		{
			case 0: src[0][0] = xi; src[0][1] = yi; count++; break;
			case 1: src[1][0] = xi; src[1][1] = yi; count++; break;
			case 2: src[2][0] = xi; src[2][1] = yi; count++; break;
			case 3: src[3][0] = xi; src[3][1] = yi; count = 0; getMatrix(src, tar, mat); break;
		}
	}
}
int main( int argc, char **argv)
{
	tex = (unsigned char*) malloc(4 * w * h * sizeof(unsigned char) );
	img = (unsigned char*) malloc(4 * w * h * sizeof(unsigned char) );
	loadImg("img.raw", img, w, h);
	getMatrix(src, tar, mat);
	
	glutInit(&argc,argv);
	glutInitWindowSize(w, h);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutCreateWindow("Interpolation"); 
	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene); 
	glutKeyboardFunc(keys);
	glutMouseFunc(mouse);
	
	glOrtho(-1.0,1.0f,1.0,-1.0,-1.0,1.0);
	glEnable(GL_TEXTURE_2D);
	glGenTextures(1, &texID);
	glBindTexture(GL_TEXTURE_2D, texID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
	printf("Choose image Mode by pressing \"1...4\"\nchange transform matrix by clicken four times\nscale by pressing \"-\" and \"+\"\nchange position by pressing \"W\", \"A\", \"S\" and \"D\"\npress \"ENTER\" to go to presets\n");
	
	glutMainLoop();
	return 0;
}