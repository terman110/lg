#pragma comment(lib, "glut32.lib")
#include <windows.h>
//#include <GL/gl.h>
#include <GL/glut.h>

GLfloat angle = 0.0f;

void renderScene(void) 
{
	glEnable(GL_DEPTH_TEST);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glPushMatrix();
		glRotatef(angle, 0.0f, 0.5f, 1.0f);
		glColor4f(1.0f, 0.5f, 0.0f,0.0f);
		GLfloat s = 0.4f;
		glutSolidCube(s*2.0);
		glColor4f(1.0f, 1.0f, 1.0f,0.0f);
		glBegin(GL_LINES);
			glVertex3f(-s,-s,-s);	// front unten
			glVertex3f(s,-s,-s);
			
			glVertex3f(-s,-s,s);	// r�ckseite unten
			glVertex3f(s,-s,s);
			
			glVertex3f(-s,s,-s);	// front oben
			glVertex3f(s,s,-s);
			
			glVertex3f(-s,s,s);		// r�ckseite oben
			glVertex3f(s,s,s);
			
			glVertex3f(-s,-s,-s);	// front links
			glVertex3f(-s,s,-s);
			
			glVertex3f(-s,-s,s);	// r�ckseite links
			glVertex3f(-s,s,s);
			
			glVertex3f(s,-s,-s);	// front rechts
			glVertex3f(s,s,-s);
			
			glVertex3f(s,-s,s);		// r�ckseite rechts
			glVertex3f(s,s,s);
			
			glVertex3f(-s,-s,s);	// seite links oben
			glVertex3f(-s,-s,-s);
			
			glVertex3f(-s,s,s);		// seite links unten
			glVertex3f(-s,s,-s);
			
			glVertex3f(s,-s,s);	// seite rechts oben
			glVertex3f(s,-s,-s);
			
			glVertex3f(s,s,s);		// seite rechts unten
			glVertex3f(s,s,-s);
			
		glEnd();
	glPopMatrix();
	angle++;
	glutSwapBuffers();
}

void keys(unsigned char key, int x, int y) 
{
	if (key == 27) // 27 entspricht ESC
		exit(0);
}

int main( int argc, char **argv)
{
	glutInit(&argc,argv);
	glutInitWindowSize(600, 600);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("3D-Beispiel"); 
	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene); 
	glutKeyboardFunc(keys);
	glutMainLoop();
	return 0;
}