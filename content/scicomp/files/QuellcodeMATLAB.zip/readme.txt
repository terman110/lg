Quellcode der Beispiele zur Seminararbeit "Verfahren für parabolische und hyperbolische Randwertprobleme in der finiten Differenzenmethode".

Zum Ausführen der Beispiele bitte Beispiele.m mit MATLAB aufrufen.

Erstellt mit MATLAB R2010b.

Copyright 2011 by Jan Beneke [ mail(at)janbeneke.de ]
