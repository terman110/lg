%--------------------------------------------------------------------------
%
% Beschreibung: Auswahlmen� zum Ausf�hren der Praktischen Beispiele 
%               zum Vortrag "Verfahren f�r parabolische und
%               hyperbolische Randwertprobleme" von Jan Beneke und 
%               Javed Razzaq im Modul Scientific Computing im Studiengang 
%               Applied Physics (FH-Koblenz: RheinAhrCampus Remagen)
%                                                                   
%--------------------------------------------------------------------------


clc
S =           'W�rmeleitungsgleichung 1D (parabolisch) - W�rmeverteilung in Stab  ';
S = vertcat(S,'W�rmeleitungsgleichung 2D (parabolisch) - W�rmeverteilung in Platte');
S = vertcat(S,'W�rmeleitungsgleichung 2D (parabolisch) Video                      ');
S = vertcat(S,'Wellengleichung 1D (hyperbolisch) - Saitenschwingung               ');
S = vertcat(S,'Wellengleichung 2D (hyperbolisch) - Membranschwingung              ');
S = vertcat(S,'Wellengleichung 2D Video (hyperbolisch) Video                      ');
[Selection,ok] = listdlg('ListString',S,'SelectionMode','Single',...
    'Name','Beispiel PDE ausw�hlen:','PromptString','W�hle eins der nachfolgenden Beispiele aus:',...
    'OKString','weiter','CancelString','abbrechen','ListSize',[ 500 100 ]);
if ok ~= 0

switch Selection 
    case 1     
        switch questdlg('Vorgabewerte verwenden?','W�rmeverteilung in einem Stab','Ja','Nein','Ja')
            case 'Ja'
                WLG1D;
            case 'Nein'
                WLG1D(str2double(inputdlg('Zeitintervall bis (Vorgabe: 6.0e3) ...','W�rmeverteilung in einem Stab')),...
                    str2double(inputdlg('L�nge des Stabs (Vorgabe: 1) ...','W�rmeverteilung in einem Stab')),...
                    str2double(inputdlg('Aufl�sung des Zeitintervalls (Vorgabe: 50) ...','W�rmeverteilung in einem Stab')),...
                    str2double(inputdlg('Aufl�sung des Rauminterballs (Vorgabe: 39) ...','W�rmeverteilung in einem Stab')),...
                    str2double(inputdlg('W�rmeleitkoeffizient (Vorgabe: 1.0e-5) ...','W�rmeverteilung in einem Stab'))); 
        end
    case 2
        switch questdlg('Vorgabewerte verwenden?','W�rmeverteilung in einer Platte','Ja','Nein','Ja')
            case 'Ja'
                WLG2D;
            case 'Nein'
                WLG2D(str2double(inputdlg('Zeitpunkt (Vorgabe: 1.0e4) ...','W�rmeverteilung in einer Platte')),...
                    str2double(inputdlg('Breite der Platte (Vorgabe: 4) ...','W�rmeverteilung in einer Platte')),...
                    str2double(inputdlg('L�nge der Platte (Vorgabe: 4) ...','W�rmeverteilung in einer Platte')),...    
                    str2double(inputdlg('Aufl�sung des Zeitintervalls (Vorgabe: 20) ...','W�rmeverteilung in einer Platte')),...
                    str2double(inputdlg('Aufl�sung der Breite (Vorgabe: 19) ...','W�rmeverteilung in einer Platte')),...
                    str2double(inputdlg('Aufl�sung der L�nge (Vorgabe: 19) ...','W�rmeverteilung in einer Platte')),...
                    str2double(inputdlg('W�rmeleitkoeffizient (Vorgabe: 1.0e-4) ...','W�rmeverteilung in einer Platte')));
        end
    case 3
        switch questdlg('Vorgabewerte verwenden?','Video W�rmeverteilung','Ja','Nein','Ja')
            case 'Ja'
                WLG2DMOVIE;
            case 'Nein'
                WLG2DMOVIE(str2double(inputdlg('Startzeit (Vorgabe: 0.0)','Video W�rmeverteilung')),...
                    str2double(inputdlg('Schrittweite der Zeit (Vorgabe: 100.0)','Video W�rmeverteilung')),...
                    str2double(inputdlg('Endzeit (Vorgabe: 1.0e4)','Video W�rmeverteilung')),...
                    fullfile(uiputfile('*.avi','Zieldatei (.avi)')),...
                    str2double(inputdlg('frames per second (Vorgabe: 24)','Video W�rmeverteilung')));
        end
    case 4
        switch questdlg('Vorgabewerte verwenden?','Saitenschwingung','Ja','Nein','Ja')
            case 'Ja'
                WG1D;
            case 'Nein'
                WG1D(str2double(inputdlg('Zeitintervall bis (Vorgabe: 1.0) ...','Saitenschwingung')),...
                    str2double(inputdlg('L�nge der Saite (Vorgabe: 2) ...','Saitenschwingung')),...
                    str2double(inputdlg('Aufl�sung des Zeitintervalls (Vorgabe: 80) ...','Saitenschwingung')),...
                    str2double(inputdlg('Aufl�sung des Rauminterballs (Vorgabe: 39) ...','Saitenschwingung')),...
                    str2double(inputdlg('Wellengleichungskoeffizient (Vorgabe: 4.0) ...','Saitenschwingung')));
        end
    case 5
        switch questdlg('Vorgabewerte verwenden?','Membranschwingung','Ja','Nein','Ja')
            case 'Ja'
                WG2D;
            case 'Nein'
                WG2D(str2double(inputdlg('Zeitpunkt (Vorgabe: 2.0) ...','Membranschwingung')),...
                    str2double(inputdlg('Breite der Membran (Vorgabe: 2) ...','Membranschwingung')),...
                    str2double(inputdlg('L�nge der Membran (Vorgabe: 2) ...','Membranschwingung')),...    
                    str2double(inputdlg('Aufl�sung des Zeitintervalls (Vorgabe: 80) ...','Membranschwingung')),...
                    str2double(inputdlg('Aufl�sung der Breite (Vorgabe: 39) ...','Membranschwingung')),...
                    str2double(inputdlg('Aufl�sung der L�nge (Vorgabe: 39) ...','Membranschwingung')),...
                    str2double(inputdlg('Wellengleichungskoeffizient (Vorgabe: 0.25) ...','Membranschwingung')));                
        end
    case 6
        switch questdlg('Vorgabewerte verwenden?','Video Membranschwingung','Ja','Nein','Ja')
            case 'Ja'
                WG2DMOVIE;
            case 'Nein'
                WG2DMOVIE(str2double(inputdlg('Startzeit (Vorgabe: 0.0)','Video Membranschwingung')),...
                str2double(inputdlg('Schrittweite der Zeit (Vorgabe: 0.4)','Video Membranschwingung')),...
                str2double(inputdlg('Endzeit (Vorgabe: 2.0)','Video Membranschwingung')),...
                fullfile(uiputfile('*.avi','Zieldatei (.avi)')),...
                str2double(inputdlg('frames per second (Vorgabe: 24)','Video Membranschwingung')));
        end
end

choice = questdlg('Erneut starten?', 'Neustart?', 'Ja','Nein','Abbrechen','Nein');
switch choice; case 'Ja'; clc; close all; Beispiele; case 'Nein'; clc; close all; end;

end        