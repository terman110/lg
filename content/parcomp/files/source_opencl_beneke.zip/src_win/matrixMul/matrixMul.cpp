/** \file matrixMul.cpp
 *	
 *	Compute a matrix multiplication on CPU and GPU using OpenCL, NVIDIA CUDA, OpenMP and one host processor.
 *	Benchmark the results 
 *
 *	\author Jan-M. Beneke (mail<at>janbeneke.de)
 *	\date 24.12.2011
 *	\version 1.0
 */
 
#include "matrixMul.h"
#include "../utils.h"

#if defined (__APPLE__) || defined(MACOSX)
    #include <OpenCL/opencl.h>
#else
    #include <CL/opencl.h>
#endif

#ifdef USE_CUDA
	#include <cuda_runtime_api.h>
	#include <cutil.h>
	#include <cublas_v2.h>
	#include <shrUtils.h>
	
	extern "C" 
	void matrixMulCUDA( float* hA, float* hB, float* hC, unsigned int widthA, unsigned int heightA, unsigned int widthB, unsigned int heightB, unsigned int widthC );
#endif	// USE_CUDA

void matrixMulGPU( cl_mem hABuffer, float* hB, float* hC, unsigned int widthA, unsigned int heightA, unsigned int widthB, unsigned int heightB, unsigned int widthC );
void matrixMulCPU( float* C, const float* A, const float* B, unsigned int heightA, unsigned int widthA, unsigned int widthB);
int main( int argc, char** argv);

// Global OpenCL handles
cl_context GPUContext;
cl_kernel matMulKernel;
cl_command_queue commandQueue;

void matrixMulGPU( cl_mem hABuffer, float* hB, float* hC, unsigned int widthA, unsigned int heightA, unsigned int widthB, unsigned int heightB, unsigned int widthC )
{
	cl_event GPUDone;		// Event: When is GPU done?
    cl_event GPUExecution;	// Event: When is Execution running?

	// Create buffers (memory on device) for matrizes
    cl_mem dA = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY, heightA * widthA * sizeof(float), NULL,NULL);
	// Create OpenCL buffer on device that will be initiatlize from the host memory on first use
	cl_mem dB = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, widthB * heightB * sizeof(float), hB, NULL);
    cl_mem dC = clCreateBuffer( GPUContext, CL_MEM_WRITE_ONLY, heightA * widthC * sizeof(float), NULL,NULL);

    // Copy only assigned rows from host to device
    clEnqueueCopyBuffer( commandQueue, hABuffer, dA, 0, 0, widthA * heightA * sizeof(float), 0, NULL, NULL);        
          
    // Set the argument values for the kernel
    clSetKernelArg( matMulKernel, 0, sizeof(cl_mem), (void *) &dC);
    clSetKernelArg( matMulKernel, 1, sizeof(cl_mem), (void *) &dA);
    clSetKernelArg( matMulKernel, 2, sizeof(cl_mem), (void *) &dB);
    clSetKernelArg( matMulKernel, 3, sizeof(float) * BLOCK_SIZE *BLOCK_SIZE, 0 );
    clSetKernelArg( matMulKernel, 4, sizeof(float) * BLOCK_SIZE *BLOCK_SIZE, 0 );
    clSetKernelArg( matMulKernel, 5, sizeof(cl_int), (void *) &widthA);
    clSetKernelArg( matMulKernel, 6, sizeof(cl_int), (void *) &widthB);
    
    // Execute Multiplication in parallel
    size_t localWorkSize[] = { BLOCK_SIZE, BLOCK_SIZE};
    size_t globalWorkSize[] = { roundUp(BLOCK_SIZE, widthC), roundUp(BLOCK_SIZE, heightA)};
    
    // Warm up
    clEnqueueNDRangeKernel( commandQueue, matMulKernel, 2, 0, globalWorkSize, localWorkSize, 0, NULL, &GPUExecution);
    clFlush( commandQueue);
    
    // Launch kernel nIter times on devices	
    for (int j = -1; j < N_ITER; j++) 
    {
		// Multiplication - non-blocking execution:  launch and push to device
		clEnqueueNDRangeKernel( commandQueue, matMulKernel, 2, 0, globalWorkSize, localWorkSize, 0, NULL, &GPUExecution);
        clFlush( commandQueue);
    }

    // Sync to host
	clFinish(commandQueue);

    // Stop and print timer 
    double dNumOps = 2.0 * (double)widthA * (double)heightA * (double)widthB;
    double gflops = 1.0e-9 * dNumOps/ executionTime( GPUExecution);
	printf("\tThroughput\t= %.4e GFlops/s\n\tKernel time\t= %.4e s\n\tN elements\t= %.4e\n\tIterations\t= %i\n", gflops, executionTime( GPUExecution), dNumOps, N_ITER);

    // Non-blocking copy of result from device to host
    clEnqueueReadBuffer( commandQueue, dC, CL_FALSE, 0, widthC * sizeof(float) * heightA, hC, 0, NULL, &GPUDone);

	// CPU sync with GPU
    clWaitForEvents( 1, &GPUDone);

    // Release mem and event objects    
    clReleaseMemObject( dA);
    clReleaseMemObject( dC);
    clReleaseMemObject( dB);
    clReleaseEvent( GPUExecution);
    clReleaseEvent( GPUDone);
}

void matrixMulCPU( float* C, const float* A, const float* B, unsigned int heightA, unsigned int widthA, unsigned int widthB)
{
	// Start timer
	simpleHostTimer *timer = new simpleHostTimer();
	timer->start();

	// Compute A * B = C
    for (unsigned int i = 0; i < heightA; ++i)
        for (unsigned int j = 0; j < widthB; ++j) 
        {
            double sum = 0;
            for (unsigned int k = 0; k < widthA; ++k) 
            {
                double a = A[i * widthA + k];
                double b = B[k * widthB + j];
                sum += a * b;
            }
            C[i * widthB + j] = (float)sum;
        }

	// Stop timer and print result
	double dNumOps = 2.0 * (double)widthA * (double)heightA * (double)widthB;
    double gflops = 1.0e-9 * dNumOps/ timer->stop();
	printf("\tThroughput\t= %.4e GFlops/s\n\tKernel time\t= %.4e s\n\tN elements\t= %.4e\n\tIterations\t= %i\n\n", gflops, timer->result(), dNumOps, N_ITER);
	delete timer;
}

void matrixMulOpenMP( float* C, const float* A, const float* B, int heightA, int widthA, int widthB)
{
	// Start timer
	simpleHostTimer *timer = new simpleHostTimer();
	timer->start();

    float sum = 0.;
    // Compute A * B = C
    #pragma omp parallel for reduction( +: sum)
    for ( int i = 0; i < heightA; ++i)
		
		for ( int j = 0; j < widthB; ++j) 
		{
			sum = 0.;
			for ( int k = 0; k < widthA; ++k)
				sum += A[i * widthA + k] * B[k * widthB + j];

			C[i * widthB + j] = (float)sum;
		}

	// Stop timer and print result
	double dNumOps = 2.0 * (double)widthA * (double)heightA * (double)widthB;
    double gflops = 1.0e-9 * dNumOps/ timer->stop();
	printf("\tThroughput\t= %.4e GFlops/s\n\tKernel time\t= %.4e s\n\tN elements\t= %.4e\n\tIterations\t= %i\n", gflops, timer->result(), dNumOps, N_ITER);
	delete timer;
}


int main( int argc, char** argv)
{
    printf("Starting matrix multiplication demo ...\n"); 

	// Print all available platforms and devices
	listDevices();

	char platform_name[1024];			// Platform name buffer
	char device_name[1024];				// Device name buffer
	cl_uint platformsN = 0;				// Number of platforms
	cl_platform_id *platformIDs = NULL;	// IDs of OpenCL platforms
    cl_uint deviceCount = 0;			// Number of OpenCL devices
    cl_device_id *devices = NULL;		// IDs of all OpenCL devices
	int err = 0;						// Buffer for error informations

	simpleHostTimer *totalTimer = new simpleHostTimer();
	totalTimer->start();

	// Set matrix dimensions from header
	unsigned int widthA = WA, heightA = HA, widthB = WB, heightB = HB, widthC = WC, heightC = HC;

// Optional: Benchmark with multiple numbers of elements
//for( int ij = 2; ij < 1024; ij *= 2)
//{
//	widthA = heightA = widthB = heightB = widthC = heightC = ij * 8;
//

	printf("\nTask to compute:\n\tA(%u x %u) * B(%u x %u) = C(%u x %u)\n\n", widthA, heightA, widthB, heightB, widthC, heightC);

	// Allocate memory for matrizes on host level
    float* hA = (float*) malloc( widthA * heightA * sizeof(float));
    float* hB = (float*) malloc( widthB * heightB * sizeof(float));
    float* hC = (float*) malloc( widthC * heightC * sizeof(float));
	float* hC_CL = (float*) malloc( widthC * heightC * sizeof(float));
	float* hC_CU = (float*) malloc( widthC * heightC * sizeof(float));
	float* hC_MP = (float*) malloc( widthC * heightC * sizeof(float));

    // Fill arrays with random numbers
    fillArray( hA, widthA * heightA);
    fillArray( hB, widthB * heightB);  
	
	/*
	 *   CCC    PPP   U   U
	 *  C   C  P   P  U   U
	 *  C      PPPP   U   U
	 *  C   C  P      U   U
	 *   CCC   P       UUU
	 */
	 
    // Compute reference solution
    printf("Compute on CPU (single threaded) ...\n");
	matrixMulCPU( hC, hA, hB, heightA, widthA, widthB);
	
	/*
	 *   OOO                         CCC   L
	 *  O   O   ppp    eee   n nn   C   C  L
	 *  O   O  p   p  e   e  nn  n  C      L
	 *  O   O  pppp   eeee   n   n  C   C  L
	 *   OOO   p       eeee  n   n   CCC    LLLL
	 */

	// Get platforms on this systems
	checkCL( clGetPlatformIDs ( 0, NULL, &platformsN));
	platformIDs = (cl_platform_id*) malloc( platformsN * sizeof(cl_platform_id));
	checkCL( clGetPlatformIDs( platformsN, platformIDs, NULL) );

	// Run over all platforms
	for( cl_uint i = 0; i < platformsN; i++)
	{
		// Get platform name
		checkCL( clGetPlatformInfo( platformIDs[i], CL_PLATFORM_NAME, 1024, &platform_name, NULL) );
		
		// Get device ids on this platform
		checkCL( clGetDeviceIDs( platformIDs[i], CL_DEVICE_TYPE_ALL, NULL, NULL, &deviceCount));
		devices = (cl_device_id*) malloc( deviceCount * sizeof(cl_device_id)); 
		checkCL( clGetDeviceIDs( platformIDs[i], CL_DEVICE_TYPE_ALL, deviceCount, devices, NULL));
		
		// Run over all devices
		for( cl_uint j = 0; j < deviceCount; j++)
		{
			// Get device name
			checkCL( clGetDeviceInfo( devices[j], CL_DEVICE_NAME, 1024, &device_name, NULL) );

			// Create OpenCL context
			GPUContext = clCreateContext( 0, deviceCount, devices, NULL, NULL, &err);
			checkCL( err);

			// Create command queue
			cl_device_id device = getDeviceID( GPUContext, 0);
			commandQueue = clCreateCommandQueue( GPUContext, device, CL_QUEUE_PROFILING_ENABLE, &err);
			checkCL( err);
			
			printf("Compute using OpenCL ...\n\tPlatform #%i:\t%s\n\tDevice #%i:\t%s\n", i, platform_name, j, device_name);

			// Program setup: Load source files
			size_t programLength;
			char *source = loadProgSource( OCL_SOURCE_PATH, "", &programLength);

			// Create OpenCL program
			cl_program program = clCreateProgramWithSource( GPUContext, 1, (const char **)&source, &programLength, &err);
			checkCL( err);
		    
			// Build OpenCL program
			checkCL( clBuildProgram( program, 0, NULL, "-cl-fast-relaxed-math", NULL, NULL) );

			// Free program setup
			free(source);

			// Create OpenCL buffer pointing to the host memory
			cl_mem hABuffer = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR, widthA * heightA * sizeof(float), hA, &err);
			checkCL( err);

			// Create OpenCL kernel
			matMulKernel = clCreateKernel( program, "matrixMul", &err);
			checkCL( err);
		        
			// Run multiplication with OpenCL
			matrixMulGPU( hABuffer, hB, hC_CL, widthA, heightA, widthB, heightB, widthC);

			// Check result
			printf("\tCheck result:");
			bool OK = compare( hC_CL, hC, widthC * heightC, 1.0e-6f);
			printf("\t%s\n\n", (OK ? "result fits" : "result is wrong"));

			// Clean up resources
			checkCL( clReleaseMemObject( hABuffer) );
			checkCL( clReleaseKernel( matMulKernel ) );
			checkCL( clReleaseCommandQueue( commandQueue ) );
			checkCL( clReleaseProgram( program) );
			checkCL( clReleaseContext( GPUContext) );
		}	
		free( devices);
	}

	/*
	 *   CCC   U   U  DDD    AAAAA
	 *  C   C  U   U  D  D   A   A
	 *  C      U   U  D   D  AAAAA
	 *  C   C  U   U  D  D   A   A
	 *   CCC    UUU   DDD    A   A
	 */
#ifdef USE_CUDA
	// Get number of CUDA capable devices
	int cuDevicesN = 0;
	cudaGetDeviceCount( &cuDevicesN);
	//printf("%i CUDA capable device(s) found.\n", cuDevicesN);
	
	// Run over all CUDA devices
	for( int i = 0; i < cuDevicesN; i++)
	{
		// Get device name
		cudaDeviceProp prop;
		cudaGetDeviceProperties( &prop, i);
		printf("Compute using NVIDIA CUDA ...\n\tDevice #%i:\t%s\n", i, prop.name);
		
		// Bind device i with CUDA
		cudaSetDevice( i);
		
		// Run multiplication with CUDA
		matrixMulCUDA( hA, hB, hC_CU, widthA, heightA, widthB, heightB, widthC);
		
		// Check result
		printf("\t\tCheck result:");
		bool OK = compare( hC_CU, hC, widthC * heightC, 1.0e-6f);
		printf("\t%s\n\n", (OK ? "result fits" : "result is wrong"));
	}
#endif	// USE_CUDA

	/*
	 *   OOO                        M   M   PPP
	 *  O   O   ppp    eee   n nn   MM MM  P   P
	 *  O   O  p   p  e   e  nn  n  M M M  PPPP
	 *  O   O  pppp   eeee   n   n  M   M  P
	 *   OOO   p       eeee  n   n  M   M  P
	 */
    printf("Compute on CPU with OpenMP ...\n");
    matrixMulOpenMP( hC_MP, hA, hB, heightA, widthA, widthB);
	
	// Check result
	printf("\tCheck result:");
	bool OK = compare( hC_MP, hC, widthC * heightC, 1.0e-6f);
	printf("\t%s\n\n", (OK ? "result fits" : "result is wrong"));


    // Clean up memory
    free(hA);
    free(hB);
    free(hC);
    free(hC_CL);
    free(hC_CU);
    free(hC_MP);

// Optional: Benchmark with multiple numbers of elements
//}
//

	printf("\n\nTotal time needed:\t%.4e s", totalTimer->stop());

    // Finish
	printf("\n\nHit ENTER to exit ...");
	getchar();
    return( 0);
}