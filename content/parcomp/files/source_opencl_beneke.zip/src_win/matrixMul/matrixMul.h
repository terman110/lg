/** \file matrixMul.h
 *	
 *	Compute a matrix multiplication on CPU and GPU using OpenCL, NVIDIA CUDA, OpenMP and one host processor.
 *	Benchmark the results 
 *
 *	\author Jan-M. Beneke (mail<at>janbeneke.de)
 *	\date 24.12.2011
 *	\version 1.0
 */

#ifndef _MATRIXMUL_H_
#define _MATRIXMUL_H_

// File path has to be changed for MAC OSX and maybe for some linux/ unix distributions
#if defined (__APPLE__) || defined(MACOSX)
    #define OCL_SOURCE_PATH "../matrixMul/matrixMul.cl"
#else
    #define OCL_SOURCE_PATH "matrixMul.cl"
#endif

// Define USE_CUDA to benchmark CUDA kernels
//#define USE_CUDA

// Define USE_OPENMP to benchmark with OpenMP
//#define USE_OPENMP

// Benchmark iterations
#define N_ITER 10

// Thread block dimensions
#define BLOCK_SIZE 16

// Matrix dimensions (multiples of the thread block size for simplicity)
#define WA (512 * BLOCK_SIZE)	// Input matrix A width
#define HA (512 * BLOCK_SIZE)	// Input matrix A height
#define WB (512 * BLOCK_SIZE)	// Input matrix B width
#define HB WA					// Input matrix B height
#define WC WB					// Resulting matrix C width 
#define HC HA					// Resulting matrix C height

// Faster element access
#define AS( i, j) As[ j + i * BLOCK_SIZE]
#define BS( i, j) Bs[ j + i * BLOCK_SIZE]

#endif // _MATRIXMUL_H_