#include <stdio.h>
#include "../utils.h"

#if defined (__APPLE__) || defined(MACOSX)
    #include <OpenCL/opencl.h>
#else
    #include <CL/opencl.h>
#endif

// Has to be changed for MAC OSX and maybe for some linux distributions
#if defined (__APPLE__) || defined(MACOSX)
    #define SOURCE_PATH "../matMulCL/matrixMul.cl"
#else
    #define SOURCE_PATH "matrixMul.cl"
#endif

// Thread block dimensions
#define BLOCK_SIZE 16

// Matrix dimensions
int WA = 32 * BLOCK_SIZE;	// Input matrix A width
int HA = 128 * BLOCK_SIZE;	// Input matrix A height
int WB = 32 * BLOCK_SIZE;	// Input matrix B width
int HB = WA;				// Input matrix B height
int WC = WB;				// Resulting matrix C width 
int HC = HA;				// Resulting matrix C height

int main( int argc, char** argv)
{
    printf("Matrix multiplication demo using OpenCL\n");
    
    cl_context GPUContext;              // Device context handle
    cl_kernel matMulKernel;             // Kernel handle
    cl_command_queue commandQueue;      // Command queue handle
    cl_program program;                 // Program handle
    cl_device_id deviceID = NULL;		// IDs of all OpenCL devices
       
    // Get OpenCL devices
    clGetDeviceIDs( NULL, CL_DEVICE_TYPE_GPU, 1, &deviceID, NULL);

    // Create OpenCL context
    GPUContext = clCreateContext( 0, 1, &deviceID, NULL, NULL, NULL);

    // Create command queue
    commandQueue = clCreateCommandQueue( GPUContext, deviceID, CL_QUEUE_PROFILING_ENABLE, NULL);

    // Allocate memory for matrizes on host level
    float* hA = (float*) malloc( WA * HA * sizeof(float));
    float* hB = (float*) malloc( WB * HB * sizeof(float));
	float* hC = (float*) malloc( WC * HC * sizeof(float));

    // Fill arrays with random numbers
    for(int i = 0; i < WA*HA; ++i) 
        hA[i] = rand() / (float) RAND_MAX;
    
    for(int i = 0; i < WB*HB; ++i) 
        hB[i] = rand() / (float) RAND_MAX;

    // Load OpenCL kernel source code
    size_t programLength;
    char *source = loadProgSource( SOURCE_PATH, "", &programLength);

    // Create OpenCL program
    program = clCreateProgramWithSource( GPUContext, 1, (const char **)&source, &programLength, NULL);

	// Free kernel source code
    free(source);
    
    // Build OpenCL program
    clBuildProgram( program, 0, NULL, "", NULL, NULL);

    // Create OpenCL kernel
    matMulKernel = clCreateKernel( program, "matrixMul", NULL);
    
    // Create OpenCL buffer pointing to the host memory
    cl_mem hABuffer = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR, WA*HA*sizeof(float), hA, NULL);

	// Create buffers (memory on device) for matrizes
    cl_mem dA = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY, WA*HA*sizeof(float), NULL,NULL);

	// Create OpenCL buffer on device that will be initiatlize from the host memory on first use
	cl_mem dB = clCreateBuffer( GPUContext, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, WB*HB*sizeof(float), hB, NULL);
    cl_mem dC = clCreateBuffer( GPUContext, CL_MEM_WRITE_ONLY, WC*HA*sizeof(float), NULL,NULL);
    
    // Copy only assigned rows from host to device
    clEnqueueCopyBuffer( commandQueue, hABuffer, dA, 0, 0, WA * HA * sizeof(float), 0, NULL, NULL);        
    
    // Set the argument values for the kernel
    clSetKernelArg( matMulKernel, 0, sizeof(cl_mem), (void *) &dC);
    clSetKernelArg( matMulKernel, 1, sizeof(cl_mem), (void *) &dA);
    clSetKernelArg( matMulKernel, 2, sizeof(cl_mem), (void *) &dB);
    clSetKernelArg( matMulKernel, 3, BLOCK_SIZE*BLOCK_SIZE*sizeof(float), 0);
    clSetKernelArg( matMulKernel, 4, BLOCK_SIZE*BLOCK_SIZE*sizeof(float), 0);
    clSetKernelArg( matMulKernel, 5, sizeof(cl_int), (void *) &WA);
    clSetKernelArg( matMulKernel, 6, sizeof(cl_int), (void *) &WB);
    
    // Execute Multiplication in parallel
    size_t localWorkSize[] = { BLOCK_SIZE, BLOCK_SIZE};
    size_t globalWorkSize[] = { WC, HA};
    
    // Launch kernel
    // Multiplication - non-blocking execution:  launch and push to device
	clEnqueueNDRangeKernel( commandQueue, matMulKernel, 2, 0, globalWorkSize, localWorkSize, 0, NULL, NULL);
    clFlush( commandQueue);
    
    // Sync to host
	clFinish(commandQueue);
    
    // Non-blocking copy of result from device to host
    clEnqueueReadBuffer( commandQueue, dC, CL_FALSE, 0, WC * sizeof(float) * HA, hC, 0, NULL, NULL);
    
    // Release mem and event objects    
    clReleaseMemObject( dA);
    clReleaseMemObject( dC);
    clReleaseMemObject( dB);

    // Clean up resources
    clReleaseMemObject( hABuffer);
    clReleaseKernel( matMulKernel);
    clReleaseCommandQueue( commandQueue);
    clReleaseProgram( program);
    clReleaseContext( GPUContext);

    // Clean up memory
    free(hA);
    free(hB);
    free(hC);

    // Finish
	printf("\n\nHit ENTER to exit ...");
	getchar();
    return 0;
}