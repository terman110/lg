/** \file utils.h
 *	
 *	Utility toolbox for e.g. timer, source file loading, etc. ...
 *
 *	\author Jan-M. Beneke (mail<at>janbeneke.de)
 *	\date 24.12.2011
 *	\version 4.2
 */
 
#ifndef UTILS_H
#define UTILS_H

#if defined (__APPLE__) || defined(MACOSX)
    #include <OpenCL/opencl.h>
#else
    #include <CL/opencl.h>
#endif

#ifdef USE_NVIDIA_API
	#include <shrUtils.h>
#else
	#include <time.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

bool checkCL( cl_int oclErrorCode);
bool compare( const float* reference, const float* data, const unsigned int size, const float epsilon);
double executionTime(cl_event &event);
int roundUp(int group_size, int global_size); 
void fillArray(float* data, int size);
char* loadProgSource(const char* filename, const char* preamble, size_t* finalLength);
cl_device_id getDeviceID(cl_context GPUContext, unsigned int n);
cl_int getGPGPUplatformID(cl_platform_id* selectedPlatformID);
void listDevices();

// Stupid timer with s resolution
class simpleHostTimer
{
	private:
		clock_t start_t;
		clock_t stop_t;
		double val;
	public:
		simpleHostTimer();
		void start();
		double stop();
		void reset();
		double result();
};

#endif // UTILS_H