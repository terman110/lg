#ifndef UTILS_H
#define UTILS_H

//#define USE_NVIDIA_API

#if defined (__APPLE__) || defined(MACOSX)
    #include <OpenCL/opencl.h>
#else
    #include <CL/opencl.h>
#endif

#ifdef USE_NVIDIA_API
	#include <shrUtils.h>
#else
	#include <time.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

bool checkCL( cl_int oclErrorCode);
bool compare( const float* reference, const float* data, const unsigned int size, const float epsilon);
double executionTime(cl_event &event);
int roundUp(int group_size, int global_size); 
void fillArray(float* data, int size);
char* loadProgSource(const char* filename, const char* preamble, size_t* finalLength);
cl_device_id getDeviceID(cl_context GPUContext, unsigned int n);
cl_int getGPGPUplatformID(cl_platform_id* selectedPlatformID);
void listDevices();

// Stupid timer with s resolution
class simpleHostTimer
{
	private:
		#ifdef USE_NVIDIA_API
			double start_v;
		#else
			time_t start_t;
			time_t stop_t;
		#endif
		double val;
	public:
		simpleHostTimer();
		void start();
		double stop();
		void reset();
		double result();
};

#endif // UTILS_H