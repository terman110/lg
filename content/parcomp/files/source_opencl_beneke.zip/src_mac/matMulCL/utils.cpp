#include "utils.h"

simpleHostTimer::simpleHostTimer()
{
	reset();
}

void simpleHostTimer::start()
{
	#ifdef USE_NVIDIA_API
		start_v = shrDeltaT(0);
	#else
		time( &start_t);
	#endif
}

double simpleHostTimer::stop()
{
	#ifdef USE_NVIDIA_API
		val = shrDeltaT(0) - start_v;
	#else
		time( &stop_t);
		val += difftime( stop_t, start_t);
	#endif
	
	return val;
}

void simpleHostTimer::reset()
{
	val = 0;
}

double simpleHostTimer::result()
{
	return val;
}


// Check function that returns an OpenCL error ID.
bool checkCL( cl_int oclErrorCode)
{
	if( oclErrorCode == CL_SUCCESS)
		return true;
	else
	{
		printf("\n\nAn OpenCL related error occured!\nError ID #%d\nPress ENTER to exit the program...\n\n", oclErrorCode);
		getchar();
		exit( oclErrorCode);
		return false;
	}
}

// Compare to arrays reference and data of size size. Return true, if error is smaler than epsilon.
bool compare( const float* reference, const float* data, const unsigned int size, const float epsilon) 
{
	if( epsilon < 0)
		return false;

    float error = 0;
    float ref = 0;

    for( unsigned int i = 0; i < size; ++i) {

        float diff = reference[i] - data[i];
        error += diff * diff;
        ref += reference[i] * reference[i];
    }

    float normRef = sqrtf(ref);
    if ( fabs(ref) < 1e-7) {
        return false;
    }
    float normError = sqrtf(error);
    error = normError / normRef;
    bool result = error < epsilon;

    return result ? true : false;
}

// Get execution time of event
double executionTime(cl_event &event)
{
    cl_ulong start, end;
    
    clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &end, NULL);
    clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &start, NULL);
    
    return (double)1.0e-9 * (end - start);
}

// Round up group_size if group_size % global_size != 0
int roundUp(int group_size, int global_size) 
{
    int r = global_size % group_size;

    if(r == 0) 
        return global_size;
    else 
        return global_size + group_size - r;
}

// Fill float array data of size with random numbers of 0 <= x <= 1
void fillArray(float* data, int size)
{
    int i; 
    const float scale = 1.f / (float) RAND_MAX;
    for (i = 0; i < size; ++i) 
        data[i] = scale * rand();
}

// Load content of File filename, append it to preamble and return. Give the total length to finalLength.
char* loadProgSource(const char* filename, const char* preamble, size_t* finalLength)
{
   	FILE* fileStream = NULL;	// File handle
	size_t sourceLength;		// Length of source

	// Open file of filename
    #ifdef _WIN32
        if(fopen_s( &fileStream, filename, "rb") != 0) 
        {       
			printf("Error: Failed to load %s!\n", filename);
			getchar();
			exit( -1000);
            return NULL;
        }
    #else
        fileStream = fopen( filename, "rb");
        if( fileStream == 0) 
        {       
            printf("Error: Failed to load %s!\n", filename);
			getchar();
            return NULL;
        }
    #endif

	// Length of preamble
    size_t preambleLength = strlen( preamble);
	
	// Determinate length of source
    fseek( fileStream, 0, SEEK_END); 
    sourceLength = ftell( fileStream);
    fseek( fileStream, 0, SEEK_SET); 

	// Malloc space for resulting string
    char* sourceString = (char*) malloc( sourceLength + preambleLength + 1); 
    
	// Put preamble to sourceString
	memcpy( sourceString, preamble, preambleLength);
    
	// Load content of file
	if( fread( ( sourceString) + preambleLength, sourceLength, 1, fileStream) != 1)
    {
        fclose( fileStream);
        free( sourceString);
        return 0;
    }

	// Close file
    fclose( fileStream);

    if( finalLength != 0)
    {
        *finalLength = sourceLength + preambleLength;
    }
    
	// End string properly
	sourceString[ sourceLength + preambleLength] = '\0';

    return sourceString;
}

// Get ID of device n associated with GPUContext
cl_device_id getDeviceID(cl_context GPUContext, unsigned int n)
{
    cl_device_id devices[512];
    clGetContextInfo( GPUContext, CL_CONTEXT_DEVICES, 512, devices, NULL);
    return devices[n];
}

// Get Id selectedPlatformID of ideal NVIDIA or ATI platform. Return error code.
cl_int getGPGPUplatformID(cl_platform_id* selectedPlatformID)
{
    char buffer[1024];				// buffer for device name
    cl_uint platformsN;			// Number of platforms
    cl_platform_id* platformIDs;	// Array of platformsN IDs of platforms
    
	// Set pointer to return to NULL
	*selectedPlatformID = NULL;		

    // Get number of available OpenCL platforms
    checkCL( clGetPlatformIDs ( 0, NULL, &platformsN));
    if(platformsN == 0)
    {
        printf("No OpenCL platform found!\n\n");
		getchar();
        return -2000;
    }
    else 
    {
        // If there is at least one platform allocate space for IDs
        platformIDs = (cl_platform_id*) malloc( platformsN * sizeof(cl_platform_id));

        // Get platform infos to find a GPGPU platform
        checkCL( clGetPlatformIDs( platformsN, platformIDs, NULL) );
        for( cl_uint i = 0; i < platformsN; ++i)
        {
            checkCL( clGetPlatformInfo( platformIDs[i], CL_PLATFORM_NAME, 1024, &buffer, NULL) );

			if( strstr( buffer, "NVIDIA") != NULL || strstr( buffer, "ATI") != NULL || strstr( buffer, "AMD") != NULL || strstr( buffer, "STEAM") != NULL)
            {
                *selectedPlatformID = platformIDs[i];
                break;
            }
        }

        // Use device zero if no NVIDIA or ATI/ AMD device found
        if( *selectedPlatformID == NULL)
        {
            *selectedPlatformID = platformIDs[0];
        }

        free(platformIDs);
    }

    return CL_SUCCESS;
}

// Print all platforms and devices
void listDevices()
{
    char buffer[1024];
    cl_uint platformsN;
    cl_platform_id* platformIDs;
	cl_uint devicesN = 0;
	cl_uint platformDevicesN;
	cl_device_id* deviceIDs;
    
    checkCL( clGetPlatformIDs ( 0, NULL, &platformsN));

    if(platformsN == 0)
    {
        printf("No OpenCL platform found!\n\n");
		getchar();
        return;
    }
    else 
    {
		
        platformIDs = (cl_platform_id*) malloc( platformsN * sizeof(cl_platform_id));
        checkCL( clGetPlatformIDs( platformsN, platformIDs, NULL) );

		for( cl_uint i = 0; i < platformsN; i++)
        {
            checkCL( clGetDeviceIDs( platformIDs[i], CL_DEVICE_TYPE_ALL, NULL, NULL, &platformDevicesN));
			devicesN += platformDevicesN;
        }

		printf("\n%d OpenCL capable platforms, with %d devices, found.", platformsN, devicesN);

        for( cl_uint i = 0; i < platformsN; i++)
        {
            checkCL( clGetPlatformInfo( platformIDs[i], CL_PLATFORM_NAME, 1024, &buffer, NULL) );
			printf("\n\t%d: %s", i, buffer);
            
			checkCL( clGetDeviceIDs( platformIDs[i], CL_DEVICE_TYPE_ALL, NULL, NULL, &platformDevicesN));
			deviceIDs = (cl_device_id*) malloc( platformDevicesN * sizeof(cl_device_id)); 
			checkCL( clGetDeviceIDs( platformIDs[i], CL_DEVICE_TYPE_ALL, platformDevicesN, deviceIDs, NULL));
			for( cl_uint j = 0; j < platformDevicesN; j++)
			{
				checkCL( clGetDeviceInfo( deviceIDs[j], CL_DEVICE_NAME, 1024, &buffer, NULL) );
				printf("\n\t\t%d: %s", j, buffer);
			}	
			free( deviceIDs);
        }

		printf("\n");
        free(platformIDs);
    }
}