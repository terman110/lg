% sqr_beam
% Fresnelpropagation eines quadratischen Strahlenb�ndels
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

L = 0.5;                % Seitenl�nge von Quell- und Beobachtungsfeld (m)
M = 250;                % Anzahl Abtastungen
dx = L/M;               % Abtastintervall
x = -L/2:dx:L/2-dx;     % Quellkoordinaten
y = x;                  

lambda = 532*10^-9;     % Wellenl�nge (m)
k = 2*pi/lambda;        % Wellenzahl
w = 0.011;              % Quellradius (m)
z = 2000;               % Propagationsweite (m)

% Quellfeld (Rechteckiges Strahlenb�ndel)
[X,Y] = meshgrid(x,y);
u1 = rect(X/(2*w)) .* rect(Y/(2*w));

% Intensit�t des Quellfeld
I1 = abs(u1.^2); 

% TF-Propagation
[u2,L2] = prop_fraunh(u1,L,lambda,z);

dx2 = L2/M;
x2 = -L2/2 : dx2 : L2/2-dx2;
y2 = x2;
[X2,Y2] = meshgrid(x2,y2);

% Resultierende Intensit�tsverteilung
I2 = abs(u2.^2);

% Analytische L�sung
I2_an = 16*w.^4./(lambda*z).^2 .* ...
    sinc((2.*w.*X2)/(lambda.*z)).^2 .* ...
    sinc((2.*w.*Y2)/(lambda.*z)).^2;

% Maximale Abweichung
max(max(abs( I2_an(M/2+1,:) - I2(M/2+1,:)))) / max(max(abs(I2_an(M/2+1,:))))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ausgabe Intensit�tsverteilung
h = figure('color','white');
imagesc(x2,y2,nthroot(I2,3));
axis square;
axis xy;
colormap('gray');
xlabel('x (m)');
ylabel('y (m)');
%title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);
print(h,'-dpng',['FH_ANAL',num2str(z),'.png']);

h = figure('color','white');
imagesc(x2,y2,nthroot(I2_an,3));
axis square;
axis xy;
colormap('gray');
xlabel('x (m)');
ylabel('y (m)');
%title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);
print(h,'-dpng',['FH_ANAL',num2str(z),'.png']);

% Ausgabe Intensit�tsprofil
h = figure('color','white');
hold on;
plot(x2,I2(M/2+1,:),'--','color','black');
plot(x2,I2_an(M/2+1,:),'color','black');
%axis([ min(x2), max(x2), 0, .25]);
axis([0.04 0.2 0 0.011 ]);
xlabel('x (m)');
ylabel('Intensit�t');
%title(['Intensit�tsprofil bei z = ',num2str(z),' m']);
print(h,'-dpng',['FH_ANAL',num2str(z),'_INT.png']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%