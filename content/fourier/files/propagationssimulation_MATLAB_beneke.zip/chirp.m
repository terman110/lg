% chirp - Plot of the chirp functions phase profile
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

x = -1:0.01:1;
y = x;

F = x.^2 + y.^2;

figure('Color',[1 1 1]);
plot3(x,y,F);
title('phase profile of the chirp function');
xlabel('x');
ylabel('y');
zlabel('k/2z');

figure;
plot(x,F);
title('x-axis phase profile of the chirp function');
xlabel('x');
ylabel('k/2z');