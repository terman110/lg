function [u2] = prop_fresnelTF(u1, L, lambda, z)
% prop_fresnelTF
% Propagator auf Basis der Fresnel-L�sung mittel Transferfunktion (TF)
% u1     - Feld in Quellebene
% L      - Seitenl�nge von Quell- und Beobachtungsfeld (m)
% lambda - Wellenl�nge (m)
% z      - Propagationsweite
% u2     - Feld in Beobachtungsebene
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

[M,N] = size(u1);                      % Quellfeldgr��e
dx = L / M;                            % Abtastintervall
k = 2 * pi / lambda;                   % Wellenzahl

fx = -1/(2*dx) : 1/L : 1/(2.*dx)-1/L;  % Frequenzkoordinaten
fy = fx;
[FX,FY] = meshgrid(fx,fy);

% Transferfunktion
H = exp( -j * pi * lambda * z * ( FX.^2 + FY.^2 ) );

% Shift der Transferfunktion
H = fftshift( H );

% Shift und Fourier-Transformation des Quellfelds
U1 = fft2( fftshift( u1 ));

% Multiplikation im Fourier-Raum
% (Faltung von u1 mit h)
U2 = H .* U1;

% Inverse Fourier-Transformation und R�ckshift
u2 = ifftshift( ifft2( U2 ));

end