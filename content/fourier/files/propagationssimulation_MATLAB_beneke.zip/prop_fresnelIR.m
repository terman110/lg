function [u2] = prop_fresnelIR(u1, L, lambda, z)
% prop_fresnelIR
% Propagator auf Basis der Fresnel-L�sung mittels Impulsantwort (IR)
% u1     - Feld in Quellebene
% L      - Seitenl�nge von Quell- und Beobachtungsfeld (m)
% lambda - Wellenl�nge (m)
% z      - Propagationsweite
% u2     - Feld in Beobachtungsebene
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

[M,N] = size(u1);                      % Quellfeldgr��e
dx = L / M;                            % Abtastintervall
k = 2 * pi / lambda;                   % Wellenzahl

x = -L/2 : dx : L/2-dx;                % Ortskoordinaten
y = x;
[X,Y] = meshgrid(x,y);

% Impuls
h = 1 / (j * lambda * z) * exp(j * k / (2 * z) * (X.^2 + Y.^2));

% Transferfunktion
H = fft2( fftshift( h)) * dx^2;

% Shift und Fourier-Transformation des Quellfelds
U1 = fft2( fftshift( u1 ));

% Multiplikation im Fourier-Raum
% (Faltung von u1 mit h)
U2 = H .* U1;

% Inverse Fourier-Transformation und R�ckshift
u2 = ifftshift( ifft2( U2 ));

end