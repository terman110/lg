% sqr_beam_fresnel_anal
% Vergleich der L�sungen der Fresnelpropagationen mit der Analytischen
% L�sung
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

fileID = fopen('sqr_beam_fresnel_anal.txt','w');

L = 0.5;                % Seitenl�nge von Quell- und Beobachtungsfeld (m)
M = 250;                 % Anzahl Abtastungen
dx = L/M;               % Abtastintervall
x = -L/2:dx:L/2-dx;     % Quellkoordinaten
y = x;                  

lambda = 532*10^-9;     % Wellenl�nge (m)
k = 2*pi/lambda;        % Wellenzahl
w = 0.051;              % Quellradius (m)
z0 = [1000,2000,4000,20000];               % Propagationsweite (m)

% Quellfeld (Rechteckiges Strahlenb�ndel)
[X,Y] = meshgrid(x,y);
u1 = rect(X/(2*w)) .* rect(Y/(2*w));

fprintf(fileID,'L = %12.8f\n',L);
fprintf(fileID,'M = %12.8f\n',M);
fprintf(fileID,'dx = %12.8f\n',dx);
fprintf(fileID,'lambda = %12.8f\n',lambda);
fprintf(fileID,'w = %12.8f\n',w);

for i = 1 : 1 : size(z0,2)    
    z = z0(1,i)
    
    % Intensit�t des Quellfeld
    I1 = abs(u1.^2); 

    % TF-Propagation
    u2_tf = prop_fresnelTF(u1,L,lambda,z);

    % Resultierende Intensit�tsverteilung
    I2_tf = abs(u2_tf.^2);

    % IR-Propagation
    u2_ir = prop_fresnelIR(u1,L,lambda,z);

    % Resultierende Intensit�tsverteilung
    I2_ir = abs(u2_ir.^2);

    % Analytische L�sung berechnen
    a_12 = sqrt(2/(lambda * z));
    alpha_1 = -a_12 * ( w + X);
    alpha_2 = a_12 * ( w - X);
    beta_1 = -a_12 * ( w + Y);
    beta_2 = a_12 * ( w - Y);
    u2_an = -j*exp(j * k * z)/2 .* ...
            ( ( mfun('FresnelC',alpha_2) - mfun('FresnelC',alpha_1) ) + ...
          j * ( mfun('FresnelS',alpha_2) - mfun('FresnelS',alpha_1) ) ) ...
          .* ...
            ( ( mfun('FresnelC',beta_2)  - mfun('FresnelC',beta_1)  ) + ...
          j * ( mfun('FresnelS',beta_2)  - mfun('FresnelS',beta_1)  ) );
    %u2_an = fftshift(u2_an);

    % Intensit�t der analytischen L�sung berechnen
    I2_an = abs(u2_an.^2);
    
    % Maximalabweichung
    max_I_tf = max( max( abs( I2_an(M/2+1,:) - I2_tf(M/2+1,:)))) / max( max( abs( I2_an(M/2+1,:)))) ;
    max_I_ir = max( max( abs( I2_an(M/2+1,:) - I2_ir(M/2+1,:)))) / max( max( abs( I2_an(M/2+1,:)))) ;

    fprintf(fileID,'\n\nz = %12.8f\n',w);
    fprintf(fileID,'\tTF:\n\t\tmax = %12.8f\n',max_I_tf);
    fprintf(fileID,'\tIR:\n\t\tmax = %12.8f\n',max_I_ir);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Ausgabe Intensit�tsverteilung
    h = figure('color','white');
    imagesc(x,y,I2_tf);
    axis square;
    axis xy;
    colormap('gray');
    xlabel('x (m)');
    ylabel('y (m)');
    %title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);
    print(h,'-dpng',['Frenel_Analytisch_TF_',num2str(z),'.png']);

    h = figure('color','white');
    imagesc(x,y,I2_ir);
    axis square;
    axis xy;
    colormap('gray');
    xlabel('x (m)');
    ylabel('y (m)');
    %title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);
    print(h,'-dpng',['Frenel_Analytisch_IR_',num2str(z),'.png']);
    
    h = figure('color','white');
    imagesc(x,y,I2_an);
    axis square;
    axis xy;
    colormap('gray');
    xlabel('x (m)');
    ylabel('y (m)');
    %title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);
    print(h,'-dpng',['Frenel_Analytisch_AN_',num2str(z),'.png']);
    
    % Ausgabe Intensit�tsprofil
    h = figure('color','white');
    hold on;
    plot(x,I2_tf(M/2+1,:),'--','color','black');
    plot(x,I2_ir(M/2+1,:),'-.','color','black');
    plot(x,I2_an(M/2+1,:),'-','color','black');
    axis tight;
    xlabel('x (m)');
    ylabel('Intensit�t');
    legend('TF','IR','Analytisch');
    print(h,'-dpng',['Frenel_Analytisch_INT_',num2str(z),'.png']);

    % Ausgabe Feldamplitude
    h = figure('color','white');
    hold on;
    plot(x,abs(u2_tf(M/2+1,:)),'--','color','black');
    plot(x,abs(u2_ir(M/2+1,:)),'-.','color','black');
    plot(x,abs(u2_an(M/2+1,:)),'-','color','black');
    axis tight;
    xlabel('x (m)');
    ylabel('Amplitude');
    legend('TF','IR','Analytisch');
    print(h,'-dpng',['Frenel_Analytisch_MAG_',num2str(z),'.png']);
    
    % Ausgabe Phase
    h = figure('color','white');
    hold on;
    plot(x,unwrap(angle(u2_tf(M/2+1,:))),'--','color','black');
    plot(x,unwrap(angle(u2_ir(M/2+1,:))),'-.','color','black');
    plot(x,unwrap(angle(u2_an(M/2+1,:))),'-','color','black');
    axis tight;
    xlabel('x (m)');
    ylabel('Phase');
    legend('TF','IR','Analytisch');
    print(h,'-dpng',['Frenel_Analytisch_PHA_',num2str(z),'.png']);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

fclose(fileID);