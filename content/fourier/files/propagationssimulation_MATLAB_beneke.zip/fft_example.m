% fft_example - Fourier transform a 1D rectangular signal
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

w = 0.055;              % rectangle half-width (m)
L = 2;                  % vector side length (m)
M = 200;                % number of samples
dx = L/M;               % sample interval (m)
x = -L/2:dx:L/2-dx;     % coordinate vector
f = rect(x/(2*w));      % signal vector

figure(1)
plot(x,f,'-o');         % signal plot
axis([-0.2 0.2 0 1.2]);
xlabel('x (m)');
ylabel('signal');
title('signal plot');

figure(2)
plot(f,'-o');           % plot signal sampled
axis([0 200 0 1.2]);
xlabel('index');
ylabel('signal');
title('sampled signal');

f0 = fftshift(f);       % shift signal
figure(3)
plot(f0);
axis([0 200 0 1.2]);
xlabel('index');
ylabel('signal');
title('shifted signal');

F0 = fft(f0) * dx;      % FFT and scale
figure(4)
plot(abs(F0));          % Plot magnitued
xlabel('index');
ylabel('FT magnitued');
title('magnitude of transformed signal');
figure(5)
plot(angle(F0));        % Plot phase
xlabel('index');
ylabel('FT phase');
title('phase of transformed signal');

F = fftshift(F0);       % center F
fx = -1/(2*dx):1/L:1/(2*dx)-(1/L);  % freq cords

figure(6)
plot(fx,abs(F));          % Plot magnitued
xlabel('fx (cyc/m)');
ylabel('FT magnitued');
title('centered magnitude of transformed signal');
figure(7)
plot(fx,angle(F));        % Plot phase
xlabel('fx (cyc/m)');
ylabel('FT phase');
title('centeredphase of transformed signal');

F_an = 2*w*sinc(2*w*fx);

figure(8)
plot(fx, abs(F), fx, abs(F_an),':');
title('compare magnitudes');
legend('discrete','analytic');
xlabel('fx (cyc/m)');
ylabel('FT magnitued');

figure(9)
plot(fx,angle(F),fx,angle(F_an),':');
title('compare phases');
legend('discrete','analytic');
xlabel('fx (cyc/m)');
ylabel('FT Phase');