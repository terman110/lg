% fraunhofer_anal
% Analytische Fraunhofer-L�sung einer monochromatisch und eben beleuchteten
% Kreisblende
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

L = 0.2;            % Seitenl�nge (m)
M = 250;            % Anzahl Abtastungen
dx = L/M;           % Abtastungsintervall
x = -L/2:dx:L/2-dx; % x-Koordinate
y = x;              % y-Koordinate
[X,Y] = meshgrid(x,y);

w = 1e-3;           % Halbwertsbreite (Blendenradius) (m)
lambda = .532e-6;   % Wellenl�nge (m)
z = 50;             % Propagationsweite (m)
k = 2*pi/lambda;    % Wellenzahl
lz = lambda*z;

% Berechnen der Intensit�t
I2 = (w.^2./lz).^2 .* (jinc(w./lz .* sqrt( X.^2 + Y.^2 ))).^2;

% Intensit�tsplot
figure('Color',[1 1 1]);
imagesc(x,y,nthroot(I2,3));
% Die dritte Wurzel dient lediglich zur Kontrastverbesserung des Bildes
%title('Intensit�tsverteilung')
xlabel('x (m)');
ylabel('y (m)');
colormap('gray');
axis square;
axis xy;

% 3D-Intensit�tsplot
figure('Color',[1 1 1]);
surfc(x,y,nthroot(I2,2),'FaceColor','interp','FaceLighting','phong')
camlight right;
shading interp;
colormap hsv;
xlabel('x (m)');
ylabel('y (m)');
zlabel('sqrt( I_2 )');

% Intensit�tsplot x-Achsenprofil
figure('Color',[1 1 1]);
plot(x,I2(M/2+1,:),'Color','black');
%title('x-Achsenprofil')
xlabel('x (m)');
ylabel('I_2');
axis square;
axis xy;
