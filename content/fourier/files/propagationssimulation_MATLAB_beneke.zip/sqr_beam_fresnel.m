% sqr_beam
% Fresnelpropagation eines quadratischen Strahlenb�ndels
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

L = 0.5;                % Seitenl�nge von Quell- und Beobachtungsfeld (m)
M = 250;                % Anzahl Abtastungen
dx = L/M;               % Abtastintervall
x = -L/2:dx:L/2-dx;     % Quellkoordinaten
y = x;                  

lambda = 532*10^-9;     % Wellenl�nge (m)
k = 2*pi/lambda;        % Wellenzahl
w = 0.051;              % Quellradius (m)
z = 2000;               % Propagationsweite (m)

% Quellfeld (Rechteckiges Strahlenb�ndel)
[X,Y] = meshgrid(x,y);
u1 = rect(X/(2*w)) .* rect(Y/(2*w));

% Intensit�t des Quellfeld
I1 = abs(u1.^2); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ausgabe Quellfeld
figure('color','white');
imagesc(x,y,I1);
axis square;
axis xy;
colormap('gray');
xlabel('x (m)');
ylabel('y (m)');
title('Intensit�tsverteilung bei z = 0 m');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% TF-Propagation
u2 = prop_fresnelTF(u1,L,lambda,z);

% Resultierende Intensit�tsverteilung
I2 = abs(u2.^2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ausgabe Intensit�tsverteilung
figure('color','white');
subplot(2,2,1);
imagesc(x,y,I2);
axis square;
axis xy;
colormap('gray');
xlabel('x (m)');
ylabel('y (m)');
title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);

% Ausgabe Intensit�tsprofil
subplot(2,2,2);
plot(x,I2(M/2+1,:),'color','black');
axis([ min(x), max(x), 0, 2]);
xlabel('x (m)');
ylabel('Intensit�t');
title(['Intensit�tsprofil bei z = ',num2str(z),' m']);

% Ausgabe Feldamplitude
subplot(2,2,3);
plot(x,abs(u2(M/2+1,:)),'color','black');
axis tight;
xlabel('x (m)');
ylabel('Amplitude');
title(['Amplitude bei z = ',num2str(z),' m']);

% Ausgabe Phase
subplot(2,2,4);
plot(x,unwrap(angle(u2(M/2+1,:))),'color','black');
axis tight;
xlabel('x (m)');
ylabel('Phase');
title(['Phase bei z = ',num2str(z),' m']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% IR-Propagation
u2 = prop_fresnelIR(u1,L,lambda,z);

% Resultierende Intensit�tsverteilung
I2 = abs(u2.^2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ausgabe Intensit�tsverteilung
figure('color','white');
subplot(2,2,1);
imagesc(x,y,I2);
axis square;
axis xy;
colormap('gray');
xlabel('x (m)');
ylabel('y (m)');
title(['Intensit�tsverteilung bei z = ',num2str(z),' m']);

% Ausgabe Intensit�tsprofil
subplot(2,2,2);
plot(x,I2(M/2+1,:),'color','black');
axis([ min(x), max(x), 0, 2]);
xlabel('x (m)');
ylabel('Intensit�t');
title(['Intensit�tsprofil bei z = ',num2str(z),' m']);

% Ausgabe Feldamplitude
subplot(2,2,3);
plot(x,abs(u2(M/2+1,:)),'color','black');
axis tight;
xlabel('x (m)');
ylabel('Amplitude');
title(['Amplitude bei z = ',num2str(z),' m']);

% Ausgabe Phase
subplot(2,2,4);
plot(x,unwrap(angle(u2(M/2+1,:))),'color','black');
axis tight;
xlabel('x (m)');
ylabel('Phase');
title(['Phase bei z = ',num2str(z),' m']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%