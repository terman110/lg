function [out] = jinc(x)
% jinc functio
% Erste Besselfunktion der Form
%
% J_1(2*pi*x)/x
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

% Maske aller Elemente in x, die ungleich 0 sind
mask = (x~=0);

% Initialisieren mit pi
% (Werte f�r alle x gleich 0)
out = pi * ones(size(x));

% Berechne Werte f�r alle x ungleich 0
out(mask) = besselj(1,2*pi*x(mask))./(x(mask));