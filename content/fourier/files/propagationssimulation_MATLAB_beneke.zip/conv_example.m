% conv_example - Convolution of two Gaussian functions
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

clc
clear all

wa = 0.3;                   % Gaussian 1 width [exp(-pi) radius] (m)
wb = 0.2;                   % Gaussian 2 width [exp(-pi) radius] (m)
L = 2;                      % Side length (m)
M = 200;                    % Number of samples
dx = L/M;                   % Sample interval (m)

x = [-L/2 : dx : L/2-dx];   % x coord
fa = exp(-pi*(x.^2)/wa^2);  % Gaussian 1
fb = exp(-pi*(x.^2)/wb^2);  % Gaussian 2

figure(1)
plot(x,fa,x,fb,'--');
title('functions');
xlabel('x (m)');

Fa = fft(fa);               % Transform fa
Fb = fft(fb);               % Transform fb
F0 = Fa .* Fb;              % Multiply pointwise
f0 = ifft(F0)*dx;           % Inverse transform and scale
f = fftshift(f0);           % Center result

figure(2)
plot(x,f);
title('convolution');
xlabel('x(m)');

figure(3)
plot(x,fa,'blue--',x,fb,'blue:',x,f,'red-');
legend('Gaussian 1', 'Gaussian 2', 'Convolution');
xlabel('x(m)');