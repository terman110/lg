function [u2,L2] = prop_fraunh(u1, L1, lambda, z)
% prop_fraunh
% Propagator der Fraunhofer-L�sung
% u1     - Feld in Quellebene
% L1     - Seitenl�nge des Quellsfeld (m)
% lambda - Wellenl�nge (m)
% z      - Propagationsweite
% u2     - Feld in Beobachtungsebene
% L2     - Seitenl�nge des Beobachtungsfeld (m)
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

[M,N] = size(u1);                      % Quellfeldgr��e
dx1 = L1 / M;                          % Abtastintervall Quellfeld
k = 2 * pi / lambda;                   % Wellenzahl 

L2 = lambda * z / dx1;                 % eitenl�nge des Beobachtungsfeld
dx2 = lambda * z / L1;                 % Abtastintervall Beobachtungsfeld
x2 = -L2/2 : dx2 : L2/2-dx2;           % Ortskoordinaten Beobachtungsfeld
y2 = x2;
[X2,Y2] = meshgrid(x2,y2);

% Berechne N�herung
c = 1 / (j * lambda * z) * exp(j * k / (2*z) * (X2.^2 + Y2.^2)); 
u2 = c .* ifftshift( fft2( fftshift(u1))) * dx1^2;
end