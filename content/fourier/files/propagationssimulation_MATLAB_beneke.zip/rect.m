function [out] = rect(x)
% rectangular function
% Author:	Jan-M. Beneke
% Contact:	www.janbeneke.de
% Date:		07.04.2012
% License:	GNU

out = abs(x) <= 1/2;
end